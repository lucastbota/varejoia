import pandas as pd
from sqlalchemy import create_engine, Table, MetaData, Column, String, DateTime, Integer, Float, ForeignKey

review_file_path = r".\csv\db_reviews.csv"
products_file_path = r".\csv\outdb_productsput.csv"

db_reviews = pd.read_csv(review_file_path, parse_dates=["date"])
db_products = pd.read_csv(products_file_path)



engine = create_engine("sqlite:///reviews.db")
metadata = MetaData()

##Criação do esquema
products_table = Table("products", metadata,
                        Column("id_product", Integer, primary_key=True),
                        Column("name", String, nullable=False)
                        )

reviews_table = Table("reviews", metadata, 
                      Column("id", Integer, primary_key=True, autoincrement=True),
                      Column("rating", Float),
                      Column("title_review", String),
                      Column("text", String),
                      Column("user_id", String),
                      Column("date", DateTime),
                      Column("helpful_vote", Integer),
                      Column("verified_purchase", Integer),
                      Column("store", String),
                      Column("id_product", Integer, ForeignKey("products.id_product"))
                      )

##remove as tabelas antes de continuar
reviews_table.drop(engine, checkfirst=True)
products_table.drop(engine, checkfirst=True)

metadata.create_all(engine)

##inserts
db_products.to_sql("products", con=engine, if_exists="append", index=False)
db_reviews.to_sql("reviews", con=engine, if_exists="append", index=False)
 
import os 
os.environ["GOOGLE_API_KEY"] = "XXX API KEY XXX"


import streamlit as st
import pandas as pd
from langgraph.graph.message import AnyMessage, add_messages
from typing_extensions import TypedDict
from typing import Annotated, Literal
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage, AIMessage
from langgraph.prebuilt.tool_node import ToolNode
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain_community.utilities import SQLDatabase
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
load_dotenv()

def load_llm(id_model, temperature):
    llm = ChatGoogleGenerativeAI(model=id_model,
               temperature=temperature, #afeta a resposta deterministica ou criativa. Valores 0.8+ a resposta da criatividade aumenta
               max_tokens=None,
               timeout=None,
               max_retries=2)
    return llm

id_model = 'models/gemini-3.8-flash'
temperature = 0.7
llm = load_llm(id_model,temperature)

# ----- Carregando do banco de dados -----

db = SQLDatabase.from_uri("sqlite:///reviews.db")

# ----- Definindo tools SQL -----

toolkit = SQLDatabaseToolkit(db=db, llm=llm)
tools_sql = toolkit.get_tools()

def format_res(res, return_thinking=False):
  res = res.strip()

  if return_thinking:
    res = res.replace("<think>", "[pensando...] ")
    res = res.replace("</think>", "\n---\n")

  else:
    if "</think>" in res:
      res = res.split("</think>")[-1].strip()

  res = res.replace("```","")
  return res


def show_res(res):
    display(Markdown(res))

from langchain_core.tools import tool

@tool
def db_query_tool(query: str) -> str:
    """
    Execute uma consulta SQL no banco de dados e retorne o resultado.
    Se a consulta for inválida ou não retornar nenhum resultado, uma mensagem de erro deverá ser retornada.
    Em caso de erro, o usuário é aconselhado a reescrever a consulta e tentar novamente
    """
    result = db.run_no_throw(query)
    if not result:
        return "Erro: A consulta falhou. Reescreva sua consulta e tente novamente"
    return result

list_tables_tool = next(tool for tool in tools_sql if tool.name == "sql_db_list_tables")

get_schema_tool = next(tool for tool in tools_sql if tool.name == "sql_db_schema")
get_schema_node = ToolNode([get_schema_tool], name="get_schema")
schema_reviews = get_schema_tool.invoke("reviews")
schema_products = get_schema_tool.invoke("products")
add_schema = f"{schema_reviews} --- {schema_products}"

def generate_query(state: AgentState):
   print("-------- Geração da Query --------")
   user_request = state["user_request"]
   product = state.get("product", "").strip()
   product = product.replace("'", "''")

   query_prompt = generate_query_prompt.format(
   dialect=db.dialect,
   top_k=100,
   user_request=user_request,
   product=product,
   schema_db=add_schema
)
   print(query_prompt)

   system_message = {
      "role": "system",
      "content": query_prompt
   }

   # o prompt pede apenas a query em texto; o nó execute_query_node lê msg.content
   response = llm.invoke([system_message] + state["messages"])

   return {"messages": [response]}

import ipywidgets as widgets
from IPython.display import display

def product_name_list():
    products = db.run("select name from products")
    products = eval(products)
    df = pd.DataFrame(products)

    product_names = df[0].tolist()
    return product_names


def content_to_text(content) -> str:
   # Gemini 3 pode devolver content como lista de blocos [{"type": "text", "text": ...}]
   if isinstance(content, str):
      return content
   if isinstance(content, list):
      return "".join(
         b if isinstance(b, str) else b.get("text", "")
         for b in content
         if isinstance(b, str) or (isinstance(b, dict) and b.get("type", "text") == "text")
      )
   return str(content)


class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    product: str
    user_request: str
    queries: str
    error: bool
    follow_up: bool
    context: str


##Listagem das tabelas
default_prompt = """Com base nas avaliações desse produto selecionado, realize as seguintes tarefas, separando claramente cada uma das três seções com títulos e delimitadores como `---`:

1. **Classificação Geral do Sentimento**
Forneça uma descrição breve do sentimento predominante nas avaliações, com base no conteúdo geral dos comentários.
Use uma classificação concisa, como: "Predominantemente Positivo", "Majoritariamente Negativo", ou "Misto, com tendência positiva", etc.

2. **Principais Pontos Positivos e Negativos**
Liste de forma resumida os principais pontos positivos e os principais pontos negativos mencionados pelos clientes.
Destaque os aspectos mais recorrentes ou impactantes. Use marcadores (bullet points) para facilitar a leitura.

3. **Resumo Geral das Avaliações**
Escreva um parágrafo curto que ofereça uma visão geral do que os clientes estão dizendo sobre o produto, capturando o tom, as preocupações, elogios e experiências gerais."""

def list_tables(state: AgentState):
   tool_call = {
      "name":"sql_db_list_tables", ##ver linha 221
      "args": {}, 
      "id": "list_tables_1", ##identificador único da chamada, usado para rastrear iterações do app
      "type": "tool_call"
   }
   user_request = state["messages"][0].content
   if user_request == "":
      user_request = default_prompt
   tool_call_msg = AIMessage(content="[Chamando sql_db_list_tables]", tool_calls=[tool_call])
   list_tables_tool = next(tool for tool in tools_sql if tool.name == "sql_db_list_tables")
   tool_result = list_tables_tool.invoke(tool_call)
   response = AIMessage(content=f"Tableas disponíveis: {tool_result.content}")

   return {
      "messages": [tool_call_msg, tool_result, response],
      "product": state.get("product", ""),
      "user_request": user_request,
      "queries": 0,
      "error": False,
      "follow_up": True,
      "context": ""
   }

def call_get_schema(state: AgentState):
   llm_with_tools = llm.bind_tools([get_schema_tool], tool_choice="any")
   # O Gemini exige que o turno de function call venha logo após um turno do usuário
   # (ou de function response). O 1º HumanMessage pode estar vazio (e é descartado),
   # então reconstruímos o histórico com o pedido efetivo e terminamos com um turno do usuário.
   history = [HumanMessage(content=state["user_request"])] + list(state["messages"][1:])
   history.append(HumanMessage(content="Chame a ferramenta para obter o schema das tabelas relevantes."))
   response = llm_with_tools.invoke(history)

   return {"messages": [response]}

generate_query_prompt = """Você é um agente projetado para interagir com um banco de dados SQL.
Dada uma pergunta de entrada, crie uma consulta {dialect} correta e pronta para ser executada, com base nas tabelas e colunas disponíveis (se baseie no schema que foi disponibilizado no histórico dessa conversa).
- Leve em consideração o resultado da query presente no histórico da conversa (se houver), e gere uma query que retorne o contexto que falta para responder ao pedido.
- Nunca consulte todas as colunas de uma tabela específica, solicite apenas as colunas relevantes para a pergunta.]
- A menos que o usuário especifique um número específico de exemplos que deseja obter, sempre limite sua consulta a, no máximo, {top_k} resultados.
- NÃO faça nenhuma instrução DML (INSERT, UPDATE, DELETE, DROP etc.) que altere dados no banco de dados.
- Se o pedido estiver relacionado a sentimentos, opiniões ou reviews, gere uma query que traga as reviews do produto indicado.
- Se for um pedido mais geral (como itens mais vendidos, categorias, ou dados agregados), gere uma query apropriada para isso.
- Retorne APENAS a query em formato de string normal, sem aspas no início ou fim. Não retorne mais nada em sua mensagem, sem comentários ou observações.

Gere com base em pedidos do usuário.
Produto selecionado (se aplicável): "{product}".
Pedido: "{user_request}".
Schema: "{schema_db}"
"""

#1 nó.
def generate_query(state: AgentState):
  product = state["product"]
  product = product.replace("'", "''")
  query = f"""
        SELECT r.text
        FROM reviews r
        INNER JOIN products p ON r.id_product = p.id_product
        WHERE p.name LIKE '%{product}%'
        LIMIT 3
    """
  return {
      "messages": [AIMessage(content=f"Query gerada: {query.strip()}")],
      "query": query.strip()
  }

check_query_prompt = """
You are a SQL expert with a strong attention to detail.
Double check the {dialect} query for common mistakes, including:
- Using NOT IN with NULL values
- Using UNION when UNION ALL should have been used
- Using BETWEEN for exclusive ranges
- Data type mismatch in predicates
- Properly quoting identifiers
- Using the correct number of arguments for functions
- Casting to the correct data type
- Using the proper columns for joins

Important: If there are any of the above mistakes, rewrite the query. If there are no mistakes,
just reproduce the original query. Do not explain or justify, simply return the query itself.

Return only the raw SQL query, without markdown fences.
""".format(dialect=db.dialect)

def check_query(state: AgentState):
  print("----- Checagem de query")

  system_message = {
      "role": "system",
      "content": check_query_prompt
  }

  last_msg = state["messages"][-1]
  tool_calls = getattr(last_msg, "tool_calls", None)

  if tool_calls:
    query = tool_calls[0]["args"].get("query", "").strip()
  else:
    query = content_to_text(last_msg.content).replace("```sql", "").replace("```", "").strip()

  if not query:
    raise ValueError("Query está vazia. Não é possível verificar.")

  user_message = {"role": "user", "content": query}

  response = llm.invoke([system_message, user_message])
  response.id = last_msg.id

  return {"messages": [response]}

def execute_query_node(state: AgentState) -> AgentState:
   print("------- Execução da query")
   try:
    msg = state["messages"][-1]
    query = content_to_text(msg.content).replace("```sql","").replace("```", "")
    print("Query a ser executada: " +str(query))
    result = db_query_tool.invoke(query)
    state["context"] = state.get("context") + str(result)

    response = AIMessage(content=result)

    return {
             "messages": response,
             "queries": state["queries"] +1,
             "error": False,
             "context": state["context"]
          }
   except Exception as e:
      error_msg = AIMessage(content=f"Erro na execução:  {str(e)}")
      return {
         "messages": [error_msg],
         "queries": state["queries"] +1,
         "error": True
      }


max_queries = 2

def final_answer_node(state: AgentState) -> AgentState:
   user_request = state["user_request"]
   query_result = state["context"]
   queries = state["queries"]

   if queries < max_queries:
    print("Query #" + str(state["queries"]))
    condition = """- Antes, avalie se esse resultado já responde completamente a tudo o que foi pedido.
    - Se você achar que falta algo essencial para responder à pergunta (por exemplo, avaliações do produto ou informação específica que foi pedida), retorne como resposta exatamente essa string: __continue__
    - Nesse caso, retorne __continue__ sem aspas ou pontuações no início ou fim. Não retorne mais nada em sua mensagem, não inclua comentários ou observações."""
   else:
    print("Finalizando...")
    condition = ""

   prompt = f"""
   Você é um assistente prestativo, especializado em análise de sentimentos e avaliação de feedback de clientes sobre produtos.
   Com base no pedido do usuário ('{user_request}') e no resultado da consulta SQL (fornecido mais abaixo) gere uma resposta clara e útil em português.
   {condition}
   Resultado da consulta:
   {query_result}
   """
   print(prompt)

   llm_res = llm.invoke([prompt])

   if "__continue__" in content_to_text(llm_res.content).strip().lower():
    state["follow_up"] = True
   else:
    state["follow_up"] = False

   print(llm_res)
   return {
      "messages": [llm_res],
      "follow_up": state["follow_up"]
   }


def should_continue(state: AgentState) -> Literal["generate_query_node", "final_answer_node", END]:
   if(state.get("error")):
      if state.get("queries") < max_queries:
         return "generate_query_node"
      else:
         if state.get("context") == "":
            END

   return "final_answer_node"


def have_answer(state: AgentState) -> Literal["generate_query_node", END]:
   if state.get("follow_up"):
      return "generate_query_node"
   else:
      return END



workflow = StateGraph(AgentState)

workflow.add_node("list_tables", list_tables)
workflow.add_node("call_get_schema", call_get_schema)
workflow.add_node("get_schema", get_schema_node)
workflow.add_node("generate_query_node", generate_query)
workflow.add_node("check_query_node", check_query)
workflow.add_node("execute_query_node", execute_query_node)
workflow.add_node("final_answer_node", final_answer_node)

workflow.set_entry_point("list_tables")

workflow.add_edge("list_tables", "call_get_schema")
workflow.add_edge("call_get_schema", "get_schema")
workflow.add_edge("get_schema", "generate_query_node")
workflow.add_edge("generate_query_node", "check_query_node")
workflow.add_edge("check_query_node", "execute_query_node")
workflow.add_conditional_edges("execute_query_node", should_continue)
workflow.add_conditional_edges("final_answer_node", have_answer)

agent = workflow.compile()

# ----- Configurações Streamlit -----

st.set_page_config(page_title="Agente Analisador de Avaliações", page_icon="📋")
st.title("📋 Agente Analisador de Avaliações")

product_names = product_name_list()
product = st.selectbox("Escolha um produto: ", product_names)
input = st.text_input("Informe seu pedido (opcional): ", placeholder="Ex: resuma os pontos positivos e negativos")

if st.button("Executar análise"):
   with st.spinner("Executando..."):
      final_output = ""
      step_outputs = []

      with st.expander("Logs do Agente (Detalhes da Execução passo a passo)"):
         output_box = st.empty()
         full_stream = ""

         for step in agent.stream({"product": product, "messages": [{"role": "user", "content": input}]},  stream_mode = "values"):
            msg = step["messages"][-1]
            content = content_to_text(getattr(msg, "content", ""))
            step_outputs.append(content[:5000])
            full_stream += f"\n=====================================================\n\n{content}\n"
            output_box.markdown(full_stream)
            final_output = content
         st.markdown("### 🟢 Resultado Final")
         st.markdown(final_output)