# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Compilar
mvn compile

# Rodar a aplicação JavaFX
mvn javafx:run

# Compilar + rodar (fresh)
mvn clean javafx:run

# Build completo (JAR)
mvn clean package
```

## Stack

| Camada | Tecnologia |
|--------|-----------|
| Linguagem | Java 25 |
| Build | Maven |
| GUI | JavaFX 23 + FXML |
| ORM | JPA / Hibernate 6 (dialeto SQLite) |
| Banco | SQLite embarcado em `db/reviews.db` |
| LLM | LangChain4j + Groq (API OpenAI-compatível) |
| Config | dotenv-java (arquivo `.env` na raiz) |

## Arquitetura MVC

```
controller/MainController   ← JavaFX @FXML, orquestra UI → Services
service/AgentService        ← workflow do agente (loop generate→check→execute→answer)
service/LlmService          ← chamadas ao Groq via LangChain4j
service/DatabaseService     ← JPA (listar produtos) + JDBC (executar queries do LLM)
model/AgentState            ← estado mutável passado entre os nós do agente
model/Product, Review       ← entidades JPA
util/Prompts                ← strings de prompt (PT-BR)
resources/com/varejo/main.fxml     ← layout da tela
resources/META-INF/persistence.xml ← persistence-unit "varejo" (URL JDBC injetada em runtime)
```

## Workflow do agente

`AgentService.run()` implementa o grafo do LangGraph original:

1. **getSchema** — JDBC lê schema das tabelas `products` e `reviews`
2. **generateQuery** — LLM gera SQL com base no schema, produto e pedido
3. **checkQuery** — LLM valida/corrige a query
4. **executeQuery** — JDBC executa; acumula resultado em `AgentState.context`
5. **finalAnswer** — LLM gera análise em português; se retornar `__continue__` e `queries < MAX_QUERIES (2)`, volta ao passo 2

Execução ocorre em thread daemon (`agent-thread`) para não bloquear a UI JavaFX.

## Variáveis de ambiente (`.env`)

```
GROQ_API_KEY=...
GROQ_MODEL=llama-3.3-70b-versatile   # qualquer modelo disponível no Groq
DB_PATH=db/reviews.db                 # relativo à raiz do projeto
```

## Banco de dados

O arquivo `db/reviews.db` deve existir antes de rodar o app (criado pelo script Python original).  
O JPA está configurado com `hbm2ddl.auto=none` — não recria nem altera o schema.

Tabelas relevantes:
- `products(id_product PK, name)`
- `reviews(id PK, rating, title_review, text, user_id, date, helpful_vote, verified_purchase, store, id_product FK)`
