package com.varejo.controller;

import com.varejo.model.Product;
import com.varejo.service.AgentService;
import com.varejo.service.DatabaseService;
import com.varejo.service.LlmService;
import io.github.cdimascio.dotenv.Dotenv;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Controller MVC da tela principal.
 * Conecta a View (main.fxml) aos Services.
 */
public class MainController implements Initializable {

    @FXML private ComboBox<Product> productComboBox;
    @FXML private TextField requestTextField;
    @FXML private Button executeButton;
    @FXML private TextArea logsTextArea;
    @FXML private TextArea resultTextArea;
    @FXML private ProgressIndicator progressIndicator;

    private DatabaseService databaseService;
    private AgentService agentService;

    // Thread única para não travar a UI durante a execução do agente
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "agent-thread");
        t.setDaemon(true);
        return t;
    });

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Dotenv dotenv = Dotenv.configure().ignoreIfMissing().load();

        String groqApiKey   = dotenv.get("GROQ_API_KEY",
                System.getenv("GROQ_API_KEY") != null ? System.getenv("GROQ_API_KEY") : "");
        String groqModel    = dotenv.get("GROQ_MODEL", "llama-3.3-70b-versatile");
        String geminiApiKey = dotenv.get("GEMINI_API_KEY",
                System.getenv("GEMINI_API_KEY") != null ? System.getenv("GEMINI_API_KEY") : "");
        String geminiModel  = dotenv.get("GEMINI_MODEL", "gemini-1.5-flash");
        String dbPath       = dotenv.get("DB_PATH", "db/reviews.db");

        databaseService = new DatabaseService(dbPath);
        LlmService llmService = new LlmService(groqApiKey, groqModel, 0.7, geminiApiKey, geminiModel);
        agentService = new AgentService(databaseService, llmService);

        progressIndicator.setVisible(false);
        loadProducts();
    }

    private void loadProducts() {
        List<Product> products = databaseService.findAllProducts();
        productComboBox.setItems(FXCollections.observableArrayList(products));
        if (!products.isEmpty()) {
            productComboBox.getSelectionModel().selectFirst();
        }
    }

    @FXML
    private void onExecute() {
        Product selected = productComboBox.getSelectionModel().getSelectedItem();
        if (selected == null) {
            new Alert(Alert.AlertType.WARNING, "Selecione um produto.", ButtonType.OK).showAndWait();
            return;
        }

        String userRequest = requestTextField.getText();

        executeButton.setDisable(true);
        progressIndicator.setVisible(true);
        logsTextArea.clear();
        resultTextArea.clear();

        executor.submit(() -> {
            try {
                String result = agentService.run(
                        selected.getName(),
                        userRequest,
                        log -> Platform.runLater(() -> logsTextArea.appendText(log))
                );
                Platform.runLater(() -> {
                    resultTextArea.setText(result);
                    finishExecution();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    resultTextArea.setText("Erro inesperado: " + e.getMessage());
                    finishExecution();
                });
            }
        });
    }

    private void finishExecution() {
        executeButton.setDisable(false);
        progressIndicator.setVisible(false);
    }
}
