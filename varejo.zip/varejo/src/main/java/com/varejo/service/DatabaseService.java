package com.varejo.service;

import com.varejo.model.Product;
import jakarta.persistence.*;

import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Acesso ao banco de dados.
 * - JPA (Hibernate) para consultas tipadas (ex.: listar produtos).
 * - JDBC direto para executar queries geradas pelo LLM.
 */
public class DatabaseService {

    private final EntityManagerFactory emf;
    private final String jdbcUrl;

    public DatabaseService(String dbPath) {
        this.jdbcUrl = "jdbc:sqlite:" + dbPath;

        Map<String, Object> props = new HashMap<>();
        props.put("jakarta.persistence.jdbc.url", jdbcUrl);
        props.put("jakarta.persistence.jdbc.driver", "org.sqlite.JDBC");
        props.put("hibernate.dialect", "org.hibernate.community.dialect.SQLiteDialect");
        props.put("hibernate.show_sql", "false");
        props.put("hibernate.hbm2ddl.auto", "none");

        this.emf = Persistence.createEntityManagerFactory("varejo", props);
    }

    /** Lista todos os produtos em ordem alfabética. */
    public List<Product> findAllProducts() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT p FROM Product p ORDER BY p.name", Product.class)
                    .getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * Executa uma query SELECT gerada pelo LLM e retorna o resultado como texto.
     * Retorna string iniciando com "Erro:" em caso de falha.
     */
    public String executeQuery(String sql) {
        StringBuilder sb = new StringBuilder();
        try (Connection conn = DriverManager.getConnection(jdbcUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            ResultSetMetaData meta = rs.getMetaData();
            int cols = meta.getColumnCount();
            boolean hasRows = false;

            while (rs.next()) {
                hasRows = true;
                for (int i = 1; i <= cols; i++) {
                    if (i > 1) sb.append(" | ");
                    sb.append(rs.getString(i));
                }
                sb.append("\n");
            }

            if (!hasRows) {
                return "Erro: A consulta não retornou resultados. Reescreva a query e tente novamente.";
            }

        } catch (SQLException e) {
            return "Erro: " + e.getMessage();
        }
        return sb.toString();
    }

    /**
     * Obtém o schema das tabelas 'products' e 'reviews' via DatabaseMetaData.
     * Equivalente ao get_schema_tool do Python.
     */
    public String getSchema() {
        StringBuilder schema = new StringBuilder();
        try (Connection conn = DriverManager.getConnection(jdbcUrl)) {
            DatabaseMetaData meta = conn.getMetaData();
            for (String table : List.of("products", "reviews")) {
                schema.append("Table: ").append(table).append(" (");
                try (ResultSet cols = meta.getColumns(null, null, table, null)) {
                    boolean first = true;
                    while (cols.next()) {
                        if (!first) schema.append(", ");
                        schema.append(cols.getString("COLUMN_NAME"))
                              .append(" ")
                              .append(cols.getString("TYPE_NAME"));
                        first = false;
                    }
                }
                schema.append(")\n");
            }
        } catch (SQLException e) {
            return "Erro ao obter schema: " + e.getMessage();
        }
        return schema.toString();
    }

    public void close() {
        if (emf != null && emf.isOpen()) emf.close();
    }
}
