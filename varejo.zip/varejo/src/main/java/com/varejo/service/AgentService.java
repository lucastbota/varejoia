package com.varejo.service;

import com.varejo.model.AgentState;
import com.varejo.util.Prompts;

import java.util.function.Consumer;

/**
 * Orquestra o workflow do agente — equivalente ao StateGraph compilado do Python.
 *
 * Fluxo:
 *   getSchema → generateQuery → checkQuery → executeQuery
 *       ↑                                         ↓
 *       └─────────── (followUp) ─── finalAnswer ──┘
 *
 * Repete até max_queries ou até o LLM não retornar __continue__.
 */
public class AgentService {

    private static final int MAX_QUERIES = 2;

    private final DatabaseService databaseService;
    private final LlmService llmService;

    public AgentService(DatabaseService databaseService, LlmService llmService) {
        this.databaseService = databaseService;
        this.llmService = llmService;
    }

    /**
     * Executa o agente e retorna a resposta final.
     *
     * @param product      nome do produto selecionado
     * @param userRequest  pedido do usuário (vazio = usa prompt padrão)
     * @param logCallback  chamada a cada log de etapa (thread de background → use Platform.runLater)
     */
    public String run(String product, String userRequest, Consumer<String> logCallback) {
        String effectiveRequest = (userRequest == null || userRequest.isBlank())
                ? Prompts.DEFAULT_PROMPT
                : userRequest;

        AgentState state = new AgentState(product, effectiveRequest);

        // Etapa 1: schema (equivalente a list_tables + get_schema)
        String schema = databaseService.getSchema();
        log(logCallback, "Schema obtido:\n" + schema);

        do {
            // Etapa 2: generate_query
            String query = llmService.generateQuery(state, schema);
            log(logCallback, "Query gerada:\n" + query);

            // Etapa 3: check_query
            query = llmService.checkQuery(query);
            log(logCallback, "Query verificada:\n" + query);

            // Etapa 4: execute_query
            String result = databaseService.executeQuery(query);
            state.incrementQueries();

            if (result.startsWith("Erro:")) {
                state.setError(true);
                log(logCallback, result);
                if (state.getQueries() >= MAX_QUERIES) break;
                continue;
            }

            state.setError(false);
            state.appendContext(result);
            log(logCallback, "Resultado (primeiros 500 chars):\n"
                    + result.substring(0, Math.min(500, result.length())));

            // Etapa 5: final_answer
            String answer = llmService.finalAnswer(state, MAX_QUERIES);
            log(logCallback, "Resposta do agente:\n" + answer);

            if (answer.toLowerCase().contains("__continue__") && state.getQueries() < MAX_QUERIES) {
                state.setFollowUp(true);
                log(logCallback, "[Agente solicitou mais contexto — gerando nova query...]");
            } else {
                state.setFollowUp(false);
                state.setLastMessage(answer);
            }

        } while (state.isFollowUp() && state.getQueries() < MAX_QUERIES);

        return state.getLastMessage().isBlank()
                ? "Não foi possível gerar uma resposta com o contexto disponível."
                : state.getLastMessage();
    }

    private void log(Consumer<String> cb, String message) {
        System.out.println(message);
        if (cb != null) cb.accept(message + "\n" + "=".repeat(52) + "\n");
    }
}
