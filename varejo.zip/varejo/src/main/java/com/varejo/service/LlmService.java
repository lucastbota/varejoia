package com.varejo.service;

import com.varejo.model.AgentState;
import com.varejo.util.Prompts;
import dev.ai4j.openai4j.OpenAiHttpException;
import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.data.message.SystemMessage;
import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.googleai.GoogleAiGeminiChatModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.model.output.Response;

import java.util.List;

/**
 * Wrapper do LLM via LangChain4j.
 * Usa Groq como modelo principal; fallback para Google Gemini quando
 * Groq retornar rate_limit_exceeded ou request too large.
 */
public class LlmService {

    private final ChatLanguageModel primaryModel;
    private final ChatLanguageModel fallbackModel;

    public LlmService(String groqApiKey, String groqModelName, double temperature,
                      String geminiApiKey, String geminiModelName) {
        this.primaryModel = OpenAiChatModel.builder()
                .apiKey(groqApiKey)
                .baseUrl("https://api.groq.com/openai/v1")
                .modelName(groqModelName)
                .temperature(temperature)
                .maxRetries(1)
                .build();

        this.fallbackModel = (geminiApiKey != null && !geminiApiKey.isBlank())
                ? GoogleAiGeminiChatModel.builder()
                        .apiKey(geminiApiKey)
                        .modelName(geminiModelName)
                        .temperature(temperature)
                        .build()
                : null;
    }

    public String generateQuery(AgentState state, String schema) {
        String prompt = Prompts.GENERATE_QUERY_PROMPT
                .replace("{dialect}", "sqlite")
                .replace("{top_k}", "10")
                .replace("{user_request}", state.getUserRequest())
                .replace("{product}", state.getProduct().replace("'", "''"))
                .replace("{schema_db}", schema);

        Response<AiMessage> response = generate(
                List.of(SystemMessage.from(prompt), UserMessage.from("Gere a query SQL agora."))
        );
        return cleanSql(response.content().text());
    }

    public String checkQuery(String query) {
        Response<AiMessage> response = generate(
                List.of(SystemMessage.from(Prompts.CHECK_QUERY_PROMPT), UserMessage.from(query))
        );
        return cleanSql(response.content().text());
    }

    public String finalAnswer(AgentState state, int maxQueries) {
        String condition = state.getQueries() < maxQueries ? Prompts.CONTINUE_CONDITION : "";
        String prompt = """
                Você é um assistente prestativo, especializado em análise de sentimentos e \
                avaliação de feedback de clientes sobre produtos.
                Com base no pedido do usuário ('%s') e no resultado da consulta SQL \
                (fornecido abaixo), gere uma resposta clara e útil em português.
                %s
                Resultado da consulta:
                %s
                """.formatted(state.getUserRequest(), condition, state.getContext());

        Response<AiMessage> response = generate(List.of(UserMessage.from(prompt)));
        return response.content().text().strip();
    }

    private Response<AiMessage> generate(List<dev.langchain4j.data.message.ChatMessage> messages) {
        try {
            return primaryModel.generate(messages);
        } catch (RuntimeException e) {
            if (isFallbackTrigger(e) && fallbackModel != null) {
                System.out.println("[LlmService] Groq limit atingido — usando Gemini como fallback.");
                return fallbackModel.generate(messages);
            }
            throw e;
        }
    }

    private boolean isFallbackTrigger(Throwable e) {
        Throwable cause = e;
        while (cause != null) {
            if (cause instanceof OpenAiHttpException) {
                String msg = cause.getMessage();
                return msg != null && (msg.contains("rate_limit_exceeded") || msg.contains("Request too large"));
            }
            cause = cause.getCause();
        }
        String msg = e.getMessage();
        return msg != null && (msg.contains("rate_limit_exceeded") || msg.contains("Request too large"));
    }

    private String cleanSql(String raw) {
        return raw.replace("```sql", "").replace("```", "").strip();
    }
}
