package com.varejo.util;

/** Prompts do agente — espelha as strings do script Python. */
public final class Prompts {

    private Prompts() {}

    public static final String DEFAULT_PROMPT = """
            Com base nas avaliações desse produto selecionado, realize as seguintes tarefas, \
            separando claramente cada uma das três seções com títulos e delimitadores como `---`:

            1. **Classificação Geral do Sentimento**
            Forneça uma descrição breve do sentimento predominante nas avaliações, \
            com base no conteúdo geral dos comentários.
            Use uma classificação concisa, como: "Predominantemente Positivo", \
            "Majoritariamente Negativo", ou "Misto, com tendência positiva", etc.

            2. **Principais Pontos Positivos e Negativos**
            Liste de forma resumida os principais pontos positivos e os principais pontos negativos \
            mencionados pelos clientes.
            Destaque os aspectos mais recorrentes ou impactantes. \
            Use marcadores (bullet points) para facilitar a leitura.

            3. **Resumo Geral das Avaliações**
            Escreva um parágrafo curto que ofereça uma visão geral do que os clientes estão dizendo \
            sobre o produto, capturando o tom, as preocupações, elogios e experiências gerais.""";

    /**
     * Placeholders: {dialect}, {top_k}, {user_request}, {product}, {schema_db}
     * Substituídos em LlmService antes do envio.
     */
    public static final String GENERATE_QUERY_PROMPT = """
            Você é um agente projetado para interagir com um banco de dados SQL.
            Dada uma pergunta de entrada, crie uma consulta {dialect} correta e pronta para ser \
            executada, com base nas tabelas e colunas disponíveis.
            - Nunca consulte todas as colunas de uma tabela específica; solicite apenas as colunas \
            relevantes para a pergunta.
            - A menos que o usuário especifique um número específico, limite a no máximo {top_k} resultados.
            - NÃO faça instruções DML (INSERT, UPDATE, DELETE, DROP etc.).
            - Se o pedido envolver sentimentos ou reviews, traga as reviews do produto indicado.
            - Para pedidos gerais (mais vendidos, categorias, dados agregados), gere a query adequada.
            - Retorne APENAS a query como string simples, sem aspas extras, sem comentários.

            Produto selecionado (se aplicável): "{product}".
            Pedido: "{user_request}".
            Schema: "{schema_db}"
            """;

    public static final String CHECK_QUERY_PROMPT = """
            You are a SQL expert with a strong attention to detail.
            Double check the sqlite query for common mistakes, including:
            - Using NOT IN with NULL values
            - Using UNION when UNION ALL should have been used
            - Using BETWEEN for exclusive ranges
            - Data type mismatch in predicates
            - Properly quoting identifiers
            - Using the correct number of arguments for functions
            - Casting to the correct data type
            - Using the proper columns for joins

            Important: If there are any of the above mistakes, rewrite the query. If there are no \
            mistakes, just reproduce the original query. Do not explain or justify, simply return \
            the query itself.

            Return only the raw SQL query, without markdown fences.
            """;

    /** Injetado no prompt de resposta final quando ainda há tentativas disponíveis. */
    public static final String CONTINUE_CONDITION = """
            - Antes, avalie se esse resultado já responde completamente a tudo o que foi pedido.
            - Se faltar algo essencial, retorne exatamente: __continue__
            - Retorne __continue__ sem aspas ou pontuações. Não inclua mais nada.""";
}
