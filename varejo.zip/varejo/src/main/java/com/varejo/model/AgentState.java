package com.varejo.model;

/**
 * Estado mutável passado entre os nós do workflow do agente.
 * Equivalente ao AgentState TypedDict do Python.
 */
public class AgentState {

    private final String product;
    private final String userRequest;
    private int queries = 0;
    private boolean error = false;
    private boolean followUp = true;
    private String context = "";
    private String lastMessage = "";

    public AgentState(String product, String userRequest) {
        this.product = product;
        this.userRequest = userRequest;
    }

    public void appendContext(String text) {
        this.context += text;
    }

    public void incrementQueries() {
        this.queries++;
    }

    // --- getters / setters ---

    public String getProduct() { return product; }
    public String getUserRequest() { return userRequest; }

    public int getQueries() { return queries; }

    public boolean isError() { return error; }
    public void setError(boolean error) { this.error = error; }

    public boolean isFollowUp() { return followUp; }
    public void setFollowUp(boolean followUp) { this.followUp = followUp; }

    public String getContext() { return context; }

    public String getLastMessage() { return lastMessage; }
    public void setLastMessage(String lastMessage) { this.lastMessage = lastMessage; }
}
