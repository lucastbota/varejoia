package com.varejo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "products")
public class Product {

    @Id
    @Column(name = "id_product")
    private Integer idProduct;

    @Column(name = "name", nullable = false)
    private String name;

    public Integer getIdProduct() { return idProduct; }
    public void setIdProduct(Integer idProduct) { this.idProduct = idProduct; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    /** ComboBox exibe o nome diretamente */
    @Override
    public String toString() { return name; }
}
