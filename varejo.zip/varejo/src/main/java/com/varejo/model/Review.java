package com.varejo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Float rating;

    @Column(name = "title_review")
    private String titleReview;

    private String text;

    @Column(name = "user_id")
    private String userId;

    private LocalDateTime date;

    @Column(name = "helpful_vote")
    private Integer helpfulVote;

    @Column(name = "verified_purchase")
    private Integer verifiedPurchase;

    private String store;

    @Column(name = "id_product")
    private Integer idProduct;

    public Integer getId() { return id; }
    public Float getRating() { return rating; }

    public String getTitleReview() { return titleReview; }
    public void setTitleReview(String titleReview) { this.titleReview = titleReview; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public String getUserId() { return userId; }
    public LocalDateTime getDate() { return date; }

    public Integer getHelpfulVote() { return helpfulVote; }
    public Integer getVerifiedPurchase() { return verifiedPurchase; }

    public String getStore() { return store; }
    public Integer getIdProduct() { return idProduct; }
}
